const SPLIT_H = 6;
const MIN = 0.08;
const KEY = "html-h-pane-test1-ratios";
let ratios = [1 / 3, 1 / 3, 1 / 3];

function $(id) { return document.getElementById(id); }

function applyPanes() {
  const main = $("main");
  const panes = [...main.querySelectorAll(".pane")];
  const splits = main.querySelectorAll(".hsplit").length;
  const usable = 1 - (splits * SPLIT_H) / Math.max(main.clientHeight, 1);
  panes.forEach((p, i) => {
    p.style.flex = "0 0 " + (ratios[i] * usable * 100).toFixed(4) + "%";
  });
  $("readout").textContent = ratios.map((r, i) => "p" + i + "=" + (r * 100).toFixed(1) + "%").join("  ");
}

function persist() {
  try { localStorage.setItem(KEY, JSON.stringify(ratios)); } catch (_) {}
}

function startDrag(splitEl, ev) {
  ev.preventDefault();
  const after = Number(splitEl.dataset.after);
  const main = $("main");
  const startY = ev.clientY;
  const start = ratios.slice();
  const totalPx = Math.max(main.clientHeight - SPLIT_H * 2, 1);

  function move(e) {
    const d = (e.clientY - startY) / totalPx;
    let a = start[after] + d;
    let b = start[after + 1] - d;
    if (a < MIN) { b -= MIN - a; a = MIN; }
    if (b < MIN) { a -= MIN - b; b = MIN; }
    ratios[after] = a;
    ratios[after + 1] = b;
    applyPanes();
  }
  function up() {
    document.removeEventListener("mousemove", move);
    document.removeEventListener("mouseup", up);
    persist();
  }
  document.addEventListener("mousemove", move);
  document.addEventListener("mouseup", up);
}

document.querySelectorAll("#main .hsplit").forEach((el) => {
  el.addEventListener("mousedown", (e) => startDrag(el, e));
});

$("resetBtn").addEventListener("click", () => {
  ratios = [1 / 3, 1 / 3, 1 / 3];
  persist();
  applyPanes();
});

new ResizeObserver(applyPanes).observe($("main"));

try {
  const saved = JSON.parse(localStorage.getItem(KEY) || "null");
  if (Array.isArray(saved) && saved.length === 3) ratios = saved;
} catch (_) {}
applyPanes();
